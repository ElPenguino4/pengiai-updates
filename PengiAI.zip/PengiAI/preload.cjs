// preload.cjs
// Deliberately CommonJS (.cjs extension) regardless of the project's
// "type": "module" setting, since Electron preload scripts need to load
// this way. This is the ONLY bridge between the untrusted renderer UI
// and Node/Electron capabilities - contextIsolation is on, so the
// renderer can only do what's explicitly exposed here.

const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("pengi", {
  addSource: (title, origin, text) =>
    ipcRenderer.invoke("knowledge:addSource", { title, origin, text }),
  listSources: () => ipcRenderer.invoke("knowledge:listSources"),
  search: (question) => ipcRenderer.invoke("knowledge:search", question),

  getVideoTranscript: (url) => ipcRenderer.invoke("video:getTranscript", url),

  availableModels: () => ipcRenderer.invoke("llm:availableModels"),
  loadModel: (filename) => ipcRenderer.invoke("llm:load", filename),
  isModelLoaded: () => ipcRenderer.invoke("llm:isLoaded"),
  ask: (question, chunks) => ipcRenderer.invoke("llm:ask", { question, chunks }),

  checkForUpdate: () => ipcRenderer.invoke("update:check"),
  applyUpdate: (manifest) => ipcRenderer.invoke("update:apply", manifest),
});
