# Pengi.AI

A private, offline assistant for your Mac or PC, built entirely in
JavaScript with Electron (the same toolkit behind apps like Slack and
VS Code). It has four parts, in one window:

1. **A real embedded browser** — type in any address and browse normally.
2. **A "Save this page" button** — reads that page's text into your own
   private knowledge base, stored only on your computer.
3. **A "Save this video" button** — for YouTube links, pulls the
   video's captions in as knowledge too. (Reads captions rather than
   literally watching the video — that's what keeps it fast and
   runnable without a powerful GPU. **This JS version currently supports
   YouTube only** — the earlier Python version's broader video-site
   support didn't carry over in this rewrite.)
4. **A chat panel** — ask questions and it answers using only what
   you've saved, using an AI model that runs entirely on your computer.
   It never searches the internet on its own and never sends your data
   anywhere.

---

## Step 1 — Install Node.js 18

You need **Node.js 18 specifically**. This matters more than it might
sound: nodejs.org's homepage will hand you whatever the current version
is (often 22 or 24 by now), and those newer versions require a newer
macOS than 10.15 (Catalina) — installing one of those will fail with a
cryptic `dyld: Symbol not found` error when you try to use it. Node 18 is
the last version confirmed to still work on Catalina.

1. Go directly to **https://nodejs.org/dist/latest-v18.x/** (not the
   nodejs.org homepage) and download the `.pkg` installer for macOS.
2. Run the installer, accepting the defaults. If you already have a
   newer Node.js installed, this will replace it.
3. Confirm it worked:
   ```
   node --version
   ```
   You should see `v18.x.x`. If it shows a different major version,
   something else on your Mac (like Homebrew) may be taking priority —
   paste back what you see and it can be sorted out.

   *(Windows users: this Catalina-specific issue doesn't apply to you —
   any current Node.js LTS version from [nodejs.org](https://nodejs.org)
   works fine.)*

## Step 2 — Get the project files

Take the `PengiAI` folder you downloaded and place it somewhere easy to
find, like your Desktop.

## Step 3 — Install dependencies

In Terminal/Command Prompt:
```
cd ~/Desktop/PengiAI
npm install
```
This downloads everything the app needs, including the local AI engine
(`node-llama-cpp`). Unlike some alternatives, this one ships prebuilt
binaries for common setups, so this step usually doesn't need any extra
compiler tools.

## Step 4 — Try it out first (optional but recommended)

Before building the final installer, you can just run the app directly:
```
npm start
```
A window should open. If something looks wrong, it's much faster to fix
here than after packaging.

## Step 5 — Download a local AI model

You need one "model file" (a `.gguf` file):

1. Go to Hugging Face and search for **"Phi-3-mini-4k-instruct-gguf"** by
   Microsoft, or **"Llama-3.2-3B-Instruct-GGUF"**.
2. Download the version labeled **Q4_K_M** (good balance of quality and
   size — usually 2-4 GB).
3. Put it in Pengi.AI's models folder:
   - **Mac**: `~/Library/Application Support/Pengi.AI/models/`
   - **Windows**: `%APPDATA%\Pengi.AI\models\`
   (Create the `models` folder if it doesn't exist yet — running the app
   once via Step 4 creates the parent folder automatically.)

## Step 6 — Build the installer

```
npm run dist
```
This takes a few minutes. When it's done, look in the `dist` folder:
- **Mac**: `Pengi.AI-1.0.0.pkg`
- **Windows**: an installer `.exe` (e.g. `Pengi.AI Setup 1.0.0.exe`)

**About the `.pkg` on Mac**: since this isn't going through the App
Store, the `.pkg` isn't signed with a paid Apple Developer certificate,
so Gatekeeper will flag it as being from an unidentified developer the
first time. Right-click the `.pkg` → **Open** → **Open** again to
confirm — you only need to do this once.

## Step 7 — Install and open it

Run the `.pkg` (Mac) or the installer `.exe` (Windows) like any normal
installer. After that, **Pengi.AI** is a normal app in your Applications
folder (Mac) or Start Menu (Windows) — just open it like anything else.

---

## Using it day to day

- **Browsing** works like a normal (basic) browser — type an address,
  hit Go.
- **Save this page** adds the current page's text to your permanent,
  private knowledge base — it stays saved between app launches.
- **Save this video** works the same way for a YouTube link loaded in
  the browser.
- **Ask** questions any time — Pengi.AI searches what you've saved for
  relevant material and answers from that, using the local model.
- Everything you save lives in Pengi.AI's app data folder as plain JSON
  (see Step 5 above for the path) — delete `knowledge.json` there any
  time to start fresh.

## Setting up self-updates (optional, one-time)

Pengi.AI has a **Check for Updates** button. Since there's no official
app-store update server here, it points at a location you control:

1. Make a free public GitHub repo, e.g. `pengiai-updates`.
2. Add a `manifest.json` file there:
   ```json
   {
     "version": "1.1.0",
     "download_url": "https://github.com/YOUR_USERNAME/pengiai-updates/raw/main/pengiai_v1.1.0.zip",
     "notes": "What changed"
   }
   ```
3. When you get updated code, zip the whole project folder (so the zip
   contains `package.json`, `main.js`, etc. at its root or in a
   subfolder) and upload it to match `download_url`.
4. In `lib/updater.js`, replace `YOUR_USERNAME` in
   `UPDATE_MANIFEST_URL` with your actual GitHub username, then rebuild
   once (`npm run dist`).

After that, clicking **Check for Updates** downloads and rebuilds the
new version automatically, placing the finished installer in a
**PengiAI_Update** folder on your Desktop — run it to finish. It doesn't
install itself silently, on purpose: replacing a running app's own files
is genuinely risky, so this always leaves the final "run installer" step
to you.

## If something goes wrong

Bring the exact error message back and it can be fixed from there —
`npm install` and `npm run dist` are the two steps most likely to need a
small tweak depending on your exact machine.
