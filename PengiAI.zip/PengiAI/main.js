import { app, BrowserWindow, ipcMain } from "electron";
import path from "node:path";
import { fileURLToPath } from "node:url";

import * as knowledgeStore from "./lib/knowledgeStore.js";
import * as llmEngine from "./lib/llmEngine.js";
import * as videoIngest from "./lib/videoIngest.js";
import * as updater from "./lib/updater.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1180,
    height: 760,
    minWidth: 900,
    minHeight: 560,
    title: "Pengi.AI",
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
    },
  });
  mainWindow.loadFile(path.join(__dirname, "renderer", "index.html"));
}

app.whenReady().then(() => {
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

// ---------- IPC: knowledge base ----------

ipcMain.handle("knowledge:addSource", (event, { title, origin, text }) => {
  return knowledgeStore.addSource(title, origin, text);
});

ipcMain.handle("knowledge:listSources", () => {
  return knowledgeStore.listSources();
});

ipcMain.handle("knowledge:search", (event, question) => {
  return knowledgeStore.search(question);
});

// ---------- IPC: video ----------

ipcMain.handle("video:getTranscript", async (event, url) => {
  return videoIngest.getVideoTranscript(url);
});

// ---------- IPC: LLM ----------

ipcMain.handle("llm:availableModels", () => {
  return llmEngine.availableModels();
});

ipcMain.handle("llm:load", async (event, filename) => {
  await llmEngine.loadModel(filename);
  return { ok: true };
});

ipcMain.handle("llm:isLoaded", () => {
  return llmEngine.isLoaded();
});

ipcMain.handle("llm:ask", async (event, { question, chunks }) => {
  return llmEngine.ask(question, chunks);
});

// ---------- IPC: updates ----------

ipcMain.handle("update:check", async () => {
  return updater.checkForUpdate();
});

ipcMain.handle("update:apply", async (event, manifest) => {
  return updater.downloadAndBuild(manifest);
});
