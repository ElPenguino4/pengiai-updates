const webview = document.getElementById("webview");
const urlField = document.getElementById("urlField");
const transcript = document.getElementById("transcript");
const knowledgeLabel = document.getElementById("knowledgeLabel");

function appendChat(who, text) {
  const div = document.createElement("div");
  div.style.marginBottom = "10px";
  div.textContent = `${who}: ${text}`;
  transcript.appendChild(div);
  transcript.scrollTop = transcript.scrollHeight;
}

// ---------- Browsing ----------

function goToUrl() {
  let url = urlField.value.trim();
  if (!url) return;
  if (!url.includes("://")) url = "https://" + url;
  webview.loadURL(url).catch((e) => appendChat("Pengi.AI", `Couldn't load that: ${e.message}`));
}

document.getElementById("goBtn").addEventListener("click", goToUrl);
urlField.addEventListener("keydown", (e) => {
  if (e.key === "Enter") goToUrl();
});

document.getElementById("savePageBtn").addEventListener("click", async () => {
  try {
    const result = await webview.executeJavaScript(
      "document.title + '\\n<<<PENGI_SPLIT>>>\\n' + document.body.innerText"
    );
    const splitAt = result.indexOf("\n<<<PENGI_SPLIT>>>\n");
    const title = splitAt >= 0 ? result.slice(0, splitAt) : "Untitled page";
    const text = splitAt >= 0 ? result.slice(splitAt + "\n<<<PENGI_SPLIT>>>\n".length) : result;

    const url = webview.getURL();
    const id = await window.pengi.addSource(title.trim() || url, url, text);
    appendChat(
      "Pengi.AI",
      id ? `Saved \u201c${title.trim()}\u201d to your knowledge base.` : "That page didn't have any text to save."
    );
  } catch (e) {
    appendChat("Pengi.AI", `Couldn't read that page: ${e.message}`);
  }
  refreshKnowledgeLabel();
});

document.getElementById("saveVideoBtn").addEventListener("click", async () => {
  const url = webview.getURL();
  appendChat("Pengi.AI", "Fetching this video's captions\u2026 (this can take a few seconds)");
  try {
    const { title, transcript: text, kind } = await window.pengi.getVideoTranscript(url);
    const id = await window.pengi.addSource(title, url, text);
    appendChat(
      "Pengi.AI",
      id
        ? `Saved \u201c${title}\u201d (${kind}) to your knowledge base.`
        : "Got the video's captions but there was nothing to save."
    );
  } catch (e) {
    appendChat("Pengi.AI", e.message);
  }
  refreshKnowledgeLabel();
});

// ---------- Knowledge status ----------

async function refreshKnowledgeLabel() {
  const sources = await window.pengi.listSources();
  if (!sources.length) {
    knowledgeLabel.textContent = "Nothing saved yet.";
    return;
  }
  const names = sources.slice(-3).map((s) => s.title.slice(0, 24)).join(", ");
  const more = sources.length > 3 ? ` (+${sources.length - 3} more)` : "";
  knowledgeLabel.textContent = `${sources.length} saved \u2014 ${names}${more}`;
}

// ---------- Model loading ----------

async function populateModels() {
  const models = await window.pengi.availableModels();
  const select = document.getElementById("modelSelect");
  select.innerHTML = "";
  if (!models.length) {
    const opt = document.createElement("option");
    opt.textContent = "No .gguf models found";
    select.appendChild(opt);
    appendChat(
      "Pengi.AI",
      "No local model found yet. Download a .gguf model file (see the README) and place it in your Pengi.AI models folder."
    );
  } else {
    for (const m of models) {
      const opt = document.createElement("option");
      opt.textContent = m;
      opt.value = m;
      select.appendChild(opt);
    }
  }
}

document.getElementById("loadModelBtn").addEventListener("click", async () => {
  const select = document.getElementById("modelSelect");
  const selected = select.value;
  if (!selected || selected.startsWith("No .gguf")) {
    appendChat("Pengi.AI", "Add a .gguf model file first (see the README), then reopen the app.");
    return;
  }
  appendChat("Pengi.AI", `Loading ${selected}\u2026 (this can take a bit the first time)`);
  try {
    await window.pengi.loadModel(selected);
    appendChat("Pengi.AI", "Model loaded. Ask away.");
  } catch (e) {
    appendChat("Pengi.AI", `Couldn't load model: ${e.message}`);
  }
});

// ---------- Chat ----------

async function doAsk() {
  const field = document.getElementById("questionField");
  const question = field.value.trim();
  if (!question) return;
  field.value = "";
  appendChat("You", question);

  const loaded = await window.pengi.isModelLoaded();
  if (!loaded) {
    appendChat("Pengi.AI", "Load a local model first (top right), then ask again.");
    return;
  }

  const chunks = await window.pengi.search(question);
  try {
    const answer = await window.pengi.ask(question, chunks);
    appendChat("Pengi.AI", answer);
  } catch (e) {
    appendChat("Pengi.AI", `Something went wrong: ${e.message}`);
  }
}

document.getElementById("askBtn").addEventListener("click", doAsk);
document.getElementById("questionField").addEventListener("keydown", (e) => {
  if (e.key === "Enter") doAsk();
});

// ---------- Updates ----------

document.getElementById("checkUpdatesBtn").addEventListener("click", async () => {
  const statusEl = document.getElementById("updateStatus");
  statusEl.textContent = "Checking\u2026";
  const { hasUpdate, manifest, message } = await window.pengi.checkForUpdate();
  if (!hasUpdate) {
    statusEl.textContent = message;
    return;
  }
  appendChat("Pengi.AI", message);
  statusEl.textContent = "Downloading & building\u2026";
  const result = await window.pengi.applyUpdate(manifest);
  statusEl.textContent = "";
  appendChat("Pengi.AI", result);
});

// ---------- Init ----------

populateModels();
refreshKnowledgeLabel();
appendChat(
  "Pengi.AI",
  "Ready. Load a local model from the dropdown, browse to a page, then hit \u201cSave this page\u201d (or \u201cSave this video\u201d for YouTube links) to add it to what I know."
);
